package DAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.Conta;


public class ContaDAO {
	private Connection connection;
	public ContaDAO() throws SQLException{
		this.connection = ConnectionFactory.getConnectionFactory();
	}
	public void adiciona(Conta conta) throws SQLException{
		PreparedStatement ps = this.connection.prepareStatement("insert into Conta(agencia, numConta)values(?,?)");
		ps.setInt(1, conta.getAgencia());
		ps.setInt(2, conta.getNumConta());
		ps.execute();
		ps.close();	
	}
	
	public  Conta buscaConta(Conta conta) throws SQLException{
		PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM Conta WHERE agencia, numConta LIKE ?,?");
		ResultSet rs = stmt.executeQuery();

		rs.next();
		conta.setAgencia(conta.getAgencia());
		conta.setNumConta(conta.getNumConta());

		rs.close();
		stmt.close();
		connection.close();

		return conta;
	}
}
