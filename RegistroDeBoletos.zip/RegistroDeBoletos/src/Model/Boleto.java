package Model;
import java.util.Date;

public class Boleto {

	private int codBanco;

	private int agencia;

	private int numConta;

	private float valorBoleto;

	private String observacoes;

	private int linhaDigitavel;

	private Date dataVencimento;

	private int CpfCnpjPagador;

	private Date dataPagamento;

	private float valorPago;

	private Conta conta;
	
	
	public Boleto(int codBanco, int agencia, int numConta, float valorBoleto, String observacoes, int linhaDigitavel,
			Date dataVencimento, int cpfCnpjPagador, Date dataPagamento, float valorPago, Conta conta) {
		super();
		this.codBanco = codBanco;
		this.agencia = agencia;
		this.numConta = numConta;
		this.valorBoleto = valorBoleto;
		this.observacoes = observacoes;
		this.linhaDigitavel = linhaDigitavel;
		this.dataVencimento = dataVencimento;
		CpfCnpjPagador = cpfCnpjPagador;
		this.dataPagamento = dataPagamento;
		this.valorPago = valorPago;
		this.conta = conta;
	}
	
	public int getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(int codBanco) {
		this.codBanco = codBanco;
	}

	public int getAgencia() {
		return agencia;
	}

	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}

	public int getNumConta() {
		return numConta;
	}

	public void setNumConta(int numConta) {
		this.numConta = numConta;
	}

	public float getValorBoleto() {
		return valorBoleto;
	}

	public void setValorBoleto(float valorBoleto) {
		this.valorBoleto = valorBoleto;
	}

	public String getObservacoes() {
		return observacoes;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	public int getLinhaDigitavel() {
		return linhaDigitavel;
	}

	public void setLinhaDigitavel(int linhaDigitavel) {
		this.linhaDigitavel = linhaDigitavel;
	}

	public Date getDataVencimento() {
		return dataVencimento;
	}

	public void setDataVencimento(Date dataVencimento) {
		this.dataVencimento = dataVencimento;
	}

	public int getCpfCnpjPagador() {
		return CpfCnpjPagador;
	}

	public void setCpfCnpjPagador(int cpfCnpjPagador) {
		CpfCnpjPagador = cpfCnpjPagador;
	}

	public Date getDataPagamento() {
		return dataPagamento;
	}

	public void setDataPagamento(Date dataPagamento) {
		this.dataPagamento = dataPagamento;
	}

	public float getValorPago() {
		return valorPago;
	}

	public void setValorPago(float valorPago) {
		this.valorPago = valorPago;
	}

	public Conta getConta() {
		return conta;
	}

	public void setConta(Conta conta) {
		this.conta = conta;
	}


}
