package Model;

import java.util.Collection;

public class Fisica extends Pessoa {

	private int CPF;
	
	public Fisica(String nome, Banco banco, Endereco endereco, Conta conta, Collection<Endereco> enderecos,
			Collection<Conta> contas, int cPF) {
		super(nome, banco, endereco, conta, enderecos, contas);
		CPF = cPF;
	}

	public int getCPF() {
		return CPF;
	}

	public void setCPF(int cPF) {
		CPF = cPF;
	}

}
