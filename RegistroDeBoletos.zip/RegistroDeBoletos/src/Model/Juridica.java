package Model;

import java.util.Collection;

public class Juridica extends Pessoa {

	private int CNPJ;

	public Juridica(String nome, Banco banco, Endereco endereco, Conta conta, Collection<Endereco> enderecos,
			Collection<Conta> contas, int cNPJ) {
		super(nome, banco, endereco, conta, enderecos, contas);
		CNPJ = cNPJ;
	}

	public int getCNPJ() {
		return CNPJ;
	}

	public void setCNPJ(int cNPJ) {
		CNPJ = cNPJ;
	}

}
