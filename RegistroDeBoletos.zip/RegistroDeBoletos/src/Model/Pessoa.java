package Model;
import java.util.Collection;

public class Pessoa {

	protected String nome;

	protected Banco banco;

	protected Endereco endereco;

	protected Conta conta;

	protected Collection<Endereco> enderecos;

	protected Collection<Conta> contas;
	
	public Pessoa(String nome, Banco banco, Endereco endereco, Conta conta, Collection<Endereco> enderecos,
			Collection<Conta> contas) {
		super();
		this.nome = nome;
		this.banco = banco;
		this.endereco = endereco;
		this.conta = conta;
		this.enderecos = enderecos;
		this.contas = contas;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Banco getBanco() {
		return banco;
	}

	public void setBanco(Banco banco) {
		this.banco = banco;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public Conta getConta() {
		return conta;
	}

	public void setConta(Conta conta) {
		this.conta = conta;
	}

	public Collection<Endereco> getEnderecos() {
		return enderecos;
	}

	public void setEnderecos(Collection<Endereco> enderecos) {
		this.enderecos = enderecos;
	}

	public Collection<Conta> getContas() {
		return contas;
	}

	public void setContas(Collection<Conta> contas) {
		this.contas = contas;
	}

}
