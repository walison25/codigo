package Model;
import java.util.Collection;

public class Banco {

	private int codBanco;

	private String nomeBanco;

	private Conta conta;

	private Collection<Conta> contas;
	
	public Banco(int codBanco, String nomeBanco, Conta conta, Collection<Conta> contas) {
		super();
		this.codBanco = codBanco;
		this.nomeBanco = nomeBanco;
		this.conta = conta;
		this.contas = contas;
	}
	
	public int getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(int codBanco) {
		this.codBanco = codBanco;
	}

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public Conta getConta() {
		return conta;
	}

	public void setConta(Conta conta) {
		this.conta = conta;
	}

	public Collection<Conta> getContas() {
		return contas;
	}

	public void setContas(Collection<Conta> contas) {
		this.contas = contas;
	}

}
