package Model;
import java.util.Collection;

public class Conta {

	private int agencia;

	private int numConta;

	private Pessoa pessoa;

	private Banco banco;

	private Boleto boleto;

	private Collection<Boleto> boletos;
	

	public Conta(int agencia, int numConta, Pessoa pessoa, Banco banco, Boleto boleto, Collection<Boleto> boletos) {
		super();
		this.agencia = agencia;
		this.numConta = numConta;
		this.pessoa = pessoa;
		this.banco = banco;
		this.boleto = boleto;
		this.boletos = boletos;
	}

	
	public int getAgencia() {
		return agencia;
	}

	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}

	public int getNumConta() {
		return numConta;
	}

	public void setNumConta(int numConta) {
		this.numConta = numConta;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public Banco getBanco() {
		return banco;
	}

	public void setBanco(Banco banco) {
		this.banco = banco;
	}

	public Boleto getBoleto() {
		return boleto;
	}

	public void setBoleto(Boleto boleto) {
		this.boleto = boleto;
	}

	public Collection<Boleto> getBoletos() {
		return boletos;
	}

	public void setBoletos(Collection<Boleto> boletos) {
		this.boletos = boletos;
	}
}
