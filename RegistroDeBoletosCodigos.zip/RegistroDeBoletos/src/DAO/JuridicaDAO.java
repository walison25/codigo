package DAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.Juridica;

public class JuridicaDAO {
	private Connection connection;
	public JuridicaDAO() throws SQLException{
		this.connection = ConnectionFactory.getConnectionFactory();
	}
	public void adiciona(Juridica juridica) throws SQLException{
		PreparedStatement ps = this.connection.prepareStatement("insert into Juridica(nome, CNPJ)values(?,?)");
		ps.setString(1, juridica.getNome());
		ps.setInt(2, juridica.getCNPJ());
		ps.execute();
		ps.close();	
	}
	
	public  Juridica buscaPessoaJuridica(Juridica juridica) throws SQLException{
		PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM Juridica WHERE CNPJ LIKE ?");
		ResultSet rs = stmt.executeQuery();

		rs.next();
		juridica.setCNPJ(juridica.getCNPJ());

		rs.close();
		stmt.close();
		connection.close();

		return juridica;
	}
}