package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.Boleto;


public class BoletoDAO {
	private Connection connection;
	public BoletoDAO() throws SQLException{
		this.connection = ConnectionFactory.getConnectionFactory();
	}
	public void adiciona(Boleto boleto) throws SQLException{
		PreparedStatement ps = this.connection.prepareStatement("insert into Boleto(codBanco, agencia, numConta, valorBoleto, observacoes, linhaDigitavel, "
				+ "dataVencimento, CpfCnpjPagador, dataPagamento, valorPago)values(?,?,?,?,?,?,?,?,?,?)");
		
		ps.setInt(1, boleto.getCodBanco());
		ps.setInt(2, boleto.getAgencia());
		ps.setInt(3, boleto.getNumConta());
		ps.setFloat(4, boleto.getValorBoleto());
		ps.setString(5, boleto.getObservacoes());
		ps.setInt(6, boleto.getLinhaDigitavel());
		ps.setDate(7, (java.sql.Date) boleto.getDataVencimento());
		ps.setInt(8, boleto.getCpfCnpjPagador());
		ps.setDate(9, (java.sql.Date) boleto.getDataPagamento());
		ps.setFloat(10, boleto.getValorPago());
		ps.execute();
		ps.close();	
	}
	
	public  Boleto buscaBoletoPorCpfCnpjPagador(Boleto boleto) throws SQLException{
		PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM Boleto WHERE CpfCnpjPagador LIKE ?");
		ResultSet rs = stmt.executeQuery();

		rs.next();
		boleto.setCodBanco(boleto.getCpfCnpjPagador());

		rs.close();
		stmt.close();
		connection.close();

		return boleto;
	}
	
	public  boolean excluirBoleto(Boleto boleto) throws SQLException{
		PreparedStatement stmt = this.connection.prepareStatement("DELETE * FROM Boleto WHERE CpfCnpjPagador LIKE ?");
		ResultSet rs = stmt.executeQuery();

		rs.next();
		boleto.setCodBanco(boleto.getCpfCnpjPagador());

		rs.close();
		stmt.close();
		connection.close();

		return true;
	}
	

	
}


