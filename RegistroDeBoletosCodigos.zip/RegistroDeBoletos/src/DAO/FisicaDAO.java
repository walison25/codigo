package DAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.Fisica;


public class FisicaDAO {
	private Connection connection;
	public FisicaDAO() throws SQLException{
		this.connection = ConnectionFactory.getConnectionFactory();
	}
	public void adiciona(Fisica fisica) throws SQLException{
		PreparedStatement ps = this.connection.prepareStatement("insert into fisica(nome, CPF)values(?,?)");
		ps.setString(1, fisica.getNome());
		ps.setInt(2, fisica.getCPF());
		ps.execute();
		ps.close();	
	}
	
	public  Fisica buscaPessoaFisica(Fisica fisica) throws SQLException{
		PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM fisica WHERE CPF LIKE ?");
		ResultSet rs = stmt.executeQuery();

		rs.next();
		fisica.setCPF(fisica.getCPF());

		rs.close();
		stmt.close();
		connection.close();

		return fisica;
	}
}