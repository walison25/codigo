package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.Banco;

public class BancoDAO {
	private Connection connection;

	public BancoDAO() throws SQLException {
		this.connection = ConnectionFactory.getConnectionFactory();
	}

	public void adiciona(Banco banco) throws SQLException {
		PreparedStatement ps = this.connection.prepareStatement("insert into Banco(codBanco, nomeBanco)values(?,?)");
		ps.setInt(1, banco.getCodBanco());
		ps.setString(2, banco.getNomeBanco());
		ps.execute();
		ps.close();
	}

	public  Banco buscaBanco(Banco banco) throws SQLException{
		PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM Banco WHERE codBanco LIKE ?");
		ResultSet rs = stmt.executeQuery();

		rs.next();
		banco.setCodBanco(banco.getCodBanco());

		rs.close();
		stmt.close();
		connection.close();

		return banco;
	}
	
	public void alterarDados(Banco banco) throws SQLException {
		PreparedStatement ps = this.connection.prepareStatement("UPDATE Bancos SET codBanco=?, nomeBanco=?");
		ps.setInt(1, banco.getCodBanco());
		ps.setString(2, banco.getNomeBanco());
		ps.execute();
		ps.close();
	}
}
