package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Model.Endereco;


public class EnderecoDAO {
	private Connection connection;
	public EnderecoDAO() throws SQLException{
		this.connection = ConnectionFactory.getConnectionFactory();
	}
	public void adiciona(Endereco endereco) throws SQLException{
		PreparedStatement ps = this.connection.prepareStatement("insert into Endereco(logradouro,  numero, complemento, bairro, cidade, estado)values(?,?,?,?,?,?)");
		ps.setString(1, endereco.getLogradouro());
		ps.setInt(2, endereco.getNumero());
		ps.setString(3, endereco.getComplemento());
		ps.setString(4, endereco.getBairro());
		ps.setString(5, endereco.getCidade());
		ps.setString(7, endereco.getEstado());
		ps.execute();
		ps.close();	
	}
	
	public  Endereco buscaEndereco(Endereco endereco) throws SQLException{
		PreparedStatement stmt = this.connection.prepareStatement("SELECT * FROM Endereco WHERE logradouro,  numero LIKE ?,?");
		ResultSet rs = stmt.executeQuery();

		rs.next();
		endereco.setLogradouro(endereco.getLogradouro());
		endereco.setNumero(endereco.getNumero());

		rs.close();
		stmt.close();
		connection.close();

		return endereco;
	}
	
	public void alterarDadosEndereco(Endereco endereco) throws SQLException {
		PreparedStatement ps = this.connection.prepareStatement("UPDATE Endereco SET logradouro=?, numero=?, complemento=?, bairro=?, cidade=?, estado=?");
		ps.setString(1, endereco.getLogradouro());
		ps.setInt(2, endereco.getNumero());
		ps.setString(3, endereco.getComplemento());
		ps.setString(4, endereco.getBairro());
		ps.setString(5, endereco.getCidade());
		ps.setString(7, endereco.getEstado());
		ps.execute();
		ps.close();
	}
}

